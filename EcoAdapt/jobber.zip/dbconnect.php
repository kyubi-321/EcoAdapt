
<?php
$host = 'localhost';  // Database host
$username = 'if0_37831601';   // Database username
$password = 'Bajrangbali321';       // Database password
$database = 'if0_37831601_jobber'; // Your database name

// Create connection
$mysqli = new mysqli($host, $username, $password, $database);
$conn = $mysqli;
// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

?>
